import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import '../constants/api_constants.dart';
import '../models/menu_especial.dart';

class Menu_especialService {
  Future<List<Menu_especial>> getAll() async {
    final prefs = await SharedPreferences.getInstance();
    final token = prefs.getString('token');

    final response = await http.get(
      Uri.parse(ApiConstants.baseUrl + ApiConstants.menu_especial),
      headers: {
        'Content-Type': 'application/json',
        if (token != null) 'Authorization': 'Bearer \$token',
      },
    );

    if (response.statusCode == 200) {
      List<dynamic> body = jsonDecode(response.body);
      return body.map((e) => Menu_especial.fromJson(e)).toList();
    } else {
      throw Exception('Erro ao carregar menu_especial');
    }
  }
}
