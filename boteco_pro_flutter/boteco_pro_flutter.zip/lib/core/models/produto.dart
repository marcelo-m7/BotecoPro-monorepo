class Produto {
  final int id;
  final String nome;
  final String descricao;
  final int stockAtual;
  final int stockMinimo;

  Produto({
    required this.id,
    required this.nome,
    required this.descricao,
    required this.stockAtual,
    required this.stockMinimo,
  });

  factory Produto.fromJson(Map<String, dynamic> json) {
    return Produto(
      id: json['id_produto'],
      nome: json['nome'],
      descricao: json['descricao'],
      stockAtual: json['stock_atual'],
      stockMinimo: json['stock_minimo'],
    );
  }
}
