class Funcionario {
  final int id;
  final String nome;
  final String carreira;
  final String nivel;

  Funcionario({required this.id, required this.nome, required this.carreira, required this.nivel});

  factory Funcionario.fromJson(Map<String, dynamic> json) {
    return Funcionario(
      id: json['id_funcionario'],
      nome: json['nome'],
      carreira: json['carreira'],
      nivel: json['nivel'],
    );
  }
}