class Fatura {
  final int id;
  final String data;
  final double valorTotal;
  final double valorIva;

  Fatura({
    required this.id,
    required this.data,
    required this.valorTotal,
    required this.valorIva,
  });

  factory Fatura.fromJson(Map<String, dynamic> json) {
    return Fatura(
      id: json['id_fatura'],
      data: json['data'],
      valorTotal: json['valor_total'].toDouble(),
      valorIva: json['valor_iva'].toDouble(),
    );
  }
}
