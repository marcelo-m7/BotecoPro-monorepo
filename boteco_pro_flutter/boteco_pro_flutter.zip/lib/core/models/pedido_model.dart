class Pedido {
  final int id;
  final String dataHora;
  final String estado;

  Pedido({required this.id, required this.dataHora, required this.estado});

  factory Pedido.fromJson(Map<String, dynamic> json) {
    return Pedido(
      id: json['id_pedido'],
      dataHora: json['data_hora'],
      estado: json['estado'],
    );
  }
}