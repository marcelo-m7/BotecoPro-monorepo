class Prato {
  final int id;
  final String nome;
  final double precoVenda;
  final String? observacoes;

  Prato({
    required this.id,
    required this.nome,
    required this.precoVenda,
    this.observacoes,
  });

  factory Prato.fromJson(Map<String, dynamic> json) {
    return Prato(
      id: json['id_prato'],
      nome: json['nome'],
      precoVenda: json['preco_venda'].toDouble(),
      observacoes: json['observacoes'],
    );
  }
}
