class ApiConstants {
  static const String baseUrl = 'http://127.0.0.1:8000';
  static const String estoque = '/estoque';
  static const String pedidos = '/pedidos';
  static const String funcionarios = '/funcionarios';
  static const String faturas = '/faturas';
  static const String pratos = '/pratos';
  static const String menus = '/menus/ativos';
  static const String login = '/auth/login';
}
