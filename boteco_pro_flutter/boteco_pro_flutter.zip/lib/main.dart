import 'package:flutter/material.dart';
import 'routes/app_routes.dart';

void main() => runApp(BotecoProApp());

class BotecoProApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Boteco PRO',
      theme: ThemeData(primarySwatch: Colors.deepOrange),
      initialRoute: '/splash',
      routes: AppRoutes.routes,
    );
  }
}
