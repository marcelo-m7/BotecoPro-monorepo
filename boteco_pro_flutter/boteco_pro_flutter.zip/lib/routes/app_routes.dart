import '../modules/funcionarios/funcionarios_screen.dart';
import '../modules/login/painel_screen.dart';
import '../modules/login/splash_screen.dart';
import '../modules/pedidos/pedidos_screen.dart';
import '../modules/pedidos/novo_pedido_screen.dart';
import '../modules/pedidos/adicionar_prato_screen.dart';

class AppRoutes {
  static final routes = {
    '/splash': (context) => const SplashScreen(),
    '/adicionar-prato': (context) => AdicionarPratoScreen(),
    '/novo-pedido': (context) => NovoPedidoScreen(),
    '/pedidos': (context) => PedidosScreen(),
    '/funcionarios': (context) => FuncionariosScreen(),
    '/': (context) => PainelScreen(),
  };
}
