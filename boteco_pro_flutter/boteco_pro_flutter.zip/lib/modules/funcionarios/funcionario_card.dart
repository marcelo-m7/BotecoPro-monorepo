import 'package:flutter/material.dart';
import '../../core/models/funcionario.dart';

class FuncionarioCard extends StatelessWidget {
  final Funcionario funcionario;
  const FuncionarioCard({super.key, required this.funcionario});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 6, horizontal: 12),
      child: ListTile(
        leading: const Icon(Icons.person),
        title: Text(funcionario.nome),
        subtitle: Text('Cargo: ${funcionario.carreira} • Nível: ${funcionario.nivel}'),
      ),
    );
  }
}
