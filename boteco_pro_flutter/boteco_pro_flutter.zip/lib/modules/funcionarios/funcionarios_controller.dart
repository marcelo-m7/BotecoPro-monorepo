import 'package:flutter/material.dart';
import '../../core/models/funcionario.dart';
import '../../core/services/funcionario_service.dart';

class FuncionariosController extends ChangeNotifier {
  final FuncionarioService _service = FuncionarioService();
  List<Funcionario> funcionarios = [];
  bool isLoading = false;

  Future<void> carregarFuncionarios() async {
    isLoading = true;
    notifyListeners();
    try {
      funcionarios = await _service.getFuncionarios();
    } catch (e) {
      funcionarios = [];
    } finally {
      isLoading = false;
      notifyListeners();
    }
  }
}
