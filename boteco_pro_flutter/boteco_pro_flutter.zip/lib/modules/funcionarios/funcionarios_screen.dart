import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'funcionarios_controller.dart';
import 'funcionario_card.dart';

class FuncionariosScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) => FuncionariosController()..carregarFuncionarios(),
      child: Scaffold(
        appBar: AppBar(title: const Text('Funcionários')),
        body: Consumer<FuncionariosController>(
          builder: (context, controller, child) {
            if (controller.isLoading) {
              return const Center(child: CircularProgressIndicator());
            } else if (controller.funcionarios.isEmpty) {
              return const Center(child: Text('Nenhum funcionário encontrado.'));
            } else {
              return ListView.builder(
                itemCount: controller.funcionarios.length,
                itemBuilder: (context, index) {
                  return FuncionarioCard(funcionario: controller.funcionarios[index]);
                },
              );
            }
          },
        ),
      ),
    );
  }
}
