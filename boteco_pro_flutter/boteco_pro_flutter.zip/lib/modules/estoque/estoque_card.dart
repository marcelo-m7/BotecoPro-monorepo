import 'package:flutter/material.dart';
import '../../core/models/produto.dart';

class EstoqueCard extends StatelessWidget {
  final Produto produto;
  const EstoqueCard({super.key, required this.produto});

  @override
  Widget build(BuildContext context) {
    final bool abaixoMinimo = produto.stockAtual < produto.stockMinimo;
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 6, horizontal: 12),
      child: ListTile(
        leading: Icon(Icons.inventory, color: abaixoMinimo ? Colors.red : Colors.green),
        title: Text(produto.nome),
        subtitle: Text(produto.descricao),
        trailing: Text(
          '${produto.stockAtual} un',
          style: TextStyle(
            fontWeight: FontWeight.bold,
            color: abaixoMinimo ? Colors.red : Colors.black,
          ),
        ),
      ),
    );
  }
}
