import 'package:flutter/material.dart';
import '../../core/models/produto.dart';
import '../../core/services/estoque_service.dart';

class EstoqueController extends ChangeNotifier {
  final EstoqueService _service = EstoqueService();
  List<Produto> produtos = [];
  bool isLoading = false;

  Future<void> carregarProdutos() async {
    isLoading = true;
    notifyListeners();
    try {
      produtos = await _service.getProdutos();
    } catch (e) {
      produtos = [];
    } finally {
      isLoading = false;
      notifyListeners();
    }
  }
}
