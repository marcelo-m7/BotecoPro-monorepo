import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'estoque_controller.dart';
import 'estoque_card.dart';

class EstoqueScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) => EstoqueController()..carregarProdutos(),
      child: Scaffold(
        appBar: AppBar(title: const Text('Estoque Atual')),
        body: Consumer<EstoqueController>(
          builder: (context, controller, child) {
            if (controller.isLoading) {
              return const Center(child: CircularProgressIndicator());
            } else if (controller.produtos.isEmpty) {
              return const Center(child: Text('Nenhum produto encontrado.'));
            } else {
              return ListView.builder(
                itemCount: controller.produtos.length,
                itemBuilder: (context, index) {
                  return EstoqueCard(produto: controller.produtos[index]);
                },
              );
            }
          },
        ),
      ),
    );
  }
}
