import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class PainelScreen extends StatefulWidget {
  const PainelScreen({super.key});

  @override
  State<PainelScreen> createState() => _PainelScreenState();
}

class _PainelScreenState extends State<PainelScreen> {
  String? nomeUsuario;
  String? perfil;

  final Map<String, List<Map<String, dynamic>>> menusPorPerfil = {
    'gestor': [
      {'label': 'Estoque', 'route': '/estoque', 'icon': Icons.inventory},
      {'label': 'Funcionários', 'route': '/funcionarios', 'icon': Icons.group},
      {'label': 'Pedidos', 'route': '/pedidos', 'icon': Icons.receipt},
      {'label': 'Novo Pedido', 'route': '/novo-pedido', 'icon': Icons.add},
      {'label': 'Financeiro', 'route': '/financeiro', 'icon': Icons.bar_chart},
    ],
    'atendente': [
      {'label': 'Pedidos', 'route': '/pedidos', 'icon': Icons.receipt},
      {'label': 'Novo Pedido', 'route': '/novo-pedido', 'icon': Icons.add},
      {'label': 'Adicionar Prato', 'route': '/adicionar-prato', 'icon': Icons.restaurant},
    ],
  };

  @override
  void initState() {
    super.initState();
    carregarUsuario();
  }

  Future<void> carregarUsuario() async {
    final prefs = await SharedPreferences.getInstance();
    final usuarioStr = prefs.getString('usuario');
    if (usuarioStr != null) {
      final usuario = jsonDecode(usuarioStr);
      setState(() {
        nomeUsuario = usuario['nome'];
        perfil = usuario['perfil'];
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final menus = menusPorPerfil[perfil ?? ''] ?? [];

    return Scaffold(
      appBar: AppBar(title: Text('Painel - $nomeUsuario')),
      body: ListView.builder(
        itemCount: menus.length,
        itemBuilder: (context, index) {
          final item = menus[index];
          return ListTile(
            leading: Icon(item['icon']),
            title: Text(item['label']),
            onTap: () => Navigator.pushNamed(context, item['route']),
          );
        },
      ),
    );
  }
}
