import 'package:flutter/material.dart';
import '../../core/models/pedido.dart';
import '../../core/services/pedido_service.dart';

class PedidosController extends ChangeNotifier {
  final PedidoService _service = PedidoService();
  List<Pedido> pedidos = [];
  bool isLoading = false;

  Future<void> carregarPedidos() async {
    isLoading = true;
    notifyListeners();
    try {
      pedidos = await _service.getPedidos();
    } catch (e) {
      pedidos = [];
    } finally {
      isLoading = false;
      notifyListeners();
    }
  }
}
