import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import '../../core/constants/api_constants.dart';

class AdicionarPratoScreen extends StatefulWidget {
  const AdicionarPratoScreen({super.key});

  @override
  State<AdicionarPratoScreen> createState() => _AdicionarPratoScreenState();
}

class _AdicionarPratoScreenState extends State<AdicionarPratoScreen> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController pedidoController = TextEditingController();
  final TextEditingController pratoController = TextEditingController();
  final TextEditingController quantidadeController = TextEditingController();
  String feedbackMsg = '';
  bool isLoading = false;

  Future<void> _adicionarPrato() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() {
      isLoading = true;
      feedbackMsg = '';
    });

    final idPedido = pedidoController.text;
    final response = await http.post(
      Uri.parse('${ApiConstants.baseUrl}/pedidos/$idPedido/pratos'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({
        'id_prato': int.parse(pratoController.text),
        'quantidade': int.parse(quantidadeController.text),
      }),
    );

    setState(() {
      isLoading = false;
      feedbackMsg = response.statusCode == 200
          ? 'Prato adicionado ao pedido!'
          : 'Erro ao adicionar prato.';
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Adicionar Prato ao Pedido')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: ListView(
            children: [
              TextFormField(
                controller: pedidoController,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(labelText: 'ID do Pedido'),
                validator: (value) =>
                    value!.isEmpty ? 'Informe o ID do pedido' : null,
              ),
              TextFormField(
                controller: pratoController,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(labelText: 'ID do Prato'),
                validator: (value) =>
                    value!.isEmpty ? 'Informe o ID do prato' : null,
              ),
              TextFormField(
                controller: quantidadeController,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(labelText: 'Quantidade'),
                validator: (value) =>
                    value!.isEmpty ? 'Informe a quantidade' : null,
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: isLoading ? null : _adicionarPrato,
                child: isLoading
                    ? const CircularProgressIndicator(color: Colors.white)
                    : const Text('Adicionar Prato'),
              ),
              if (feedbackMsg.isNotEmpty)
                Padding(
                  padding: const EdgeInsets.only(top: 12),
                  child: Text(
                    feedbackMsg,
                    style: TextStyle(
                      color: feedbackMsg.contains('adicionado')
                          ? Colors.green
                          : Colors.red,
                    ),
                  ),
                )
            ],
          ),
        ),
      ),
    );
  }
}
