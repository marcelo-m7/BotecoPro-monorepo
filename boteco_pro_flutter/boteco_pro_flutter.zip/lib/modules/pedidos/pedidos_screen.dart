import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'pedidos_controller.dart';
import 'pedido_card.dart';

class PedidosScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) => PedidosController()..carregarPedidos(),
      child: Scaffold(
        appBar: AppBar(title: const Text('Pedidos')),
        body: Consumer<PedidosController>(
          builder: (context, controller, child) {
            if (controller.isLoading) {
              return const Center(child: CircularProgressIndicator());
            } else if (controller.pedidos.isEmpty) {
              return const Center(child: Text('Nenhum pedido encontrado.'));
            } else {
              return ListView.builder(
                itemCount: controller.pedidos.length,
                itemBuilder: (context, index) {
                  return PedidoCard(pedido: controller.pedidos[index]);
                },
              );
            }
          },
        ),
      ),
    );
  }
}
