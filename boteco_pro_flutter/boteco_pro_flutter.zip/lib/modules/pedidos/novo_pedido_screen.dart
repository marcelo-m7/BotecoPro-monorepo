import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import '../../core/constants/api_constants.dart';

class NovoPedidoScreen extends StatefulWidget {
  const NovoPedidoScreen({super.key});

  @override
  State<NovoPedidoScreen> createState() => _NovoPedidoScreenState();
}

class _NovoPedidoScreenState extends State<NovoPedidoScreen> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController mesaController = TextEditingController();
  final TextEditingController funcionarioController = TextEditingController();
  final TextEditingController clienteController = TextEditingController();
  final TextEditingController observacoesController = TextEditingController();

  bool isLoading = false;
  String feedbackMsg = '';

  Future<void> _realizarPedido() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() {
      isLoading = true;
      feedbackMsg = '';
    });

    final response = await http.post(
      Uri.parse('${ApiConstants.baseUrl}/pedidos'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({
        'id_mesa': int.parse(mesaController.text),
        'id_funcionario': int.parse(funcionarioController.text),
        'id_cliente': int.parse(clienteController.text),
        'observacoes': observacoesController.text,
      }),
    );

    setState(() {
      isLoading = false;
      feedbackMsg = response.statusCode == 200
          ? 'Pedido criado com sucesso!'
          : 'Erro ao criar pedido.';
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Novo Pedido')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: ListView(
            children: [
              TextFormField(
                controller: mesaController,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(labelText: 'ID da Mesa'),
                validator: (value) =>
                    value!.isEmpty ? 'Informe o ID da mesa' : null,
              ),
              TextFormField(
                controller: funcionarioController,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(labelText: 'ID do Funcionário'),
                validator: (value) =>
                    value!.isEmpty ? 'Informe o ID do funcionário' : null,
              ),
              TextFormField(
                controller: clienteController,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(labelText: 'ID do Cliente'),
                validator: (value) =>
                    value!.isEmpty ? 'Informe o ID do cliente' : null,
              ),
              TextFormField(
                controller: observacoesController,
                decoration: const InputDecoration(labelText: 'Observações'),
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: isLoading ? null : _realizarPedido,
                child: isLoading
                    ? const CircularProgressIndicator(color: Colors.white)
                    : const Text('Realizar Pedido'),
              ),
              if (feedbackMsg.isNotEmpty)
                Padding(
                  padding: const EdgeInsets.only(top: 12),
                  child: Text(
                    feedbackMsg,
                    style: TextStyle(
                      color: feedbackMsg.contains('sucesso')
                          ? Colors.green
                          : Colors.red,
                    ),
                  ),
                )
            ],
          ),
        ),
      ),
    );
  }
}
