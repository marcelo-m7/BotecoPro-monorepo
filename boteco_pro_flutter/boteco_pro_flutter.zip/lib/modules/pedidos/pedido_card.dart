import 'package:flutter/material.dart';
import '../../core/models/pedido.dart';

class PedidoCard extends StatelessWidget {
  final Pedido pedido;
  const PedidoCard({super.key, required this.pedido});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 6, horizontal: 12),
      child: ListTile(
        leading: Icon(Icons.receipt_long,
            color: pedido.estado == 'Aberto' ? Colors.orange : Colors.green),
        title: Text('Pedido #${pedido.id}'),
        subtitle: Text('Status: ${pedido.estado}
Data: ${pedido.dataHora}'),
        isThreeLine: true,
        trailing: const Icon(Icons.arrow_forward_ios, size: 16),
      ),
    );
  }
}
